import {
    addErrorHandler,
    getAppStatus,
    registerApplication,
    start,
    triggerAppChange,
} from "single-spa";
import { MICROFRONTENDS } from "./config/microfrontends";

const MFE_HOST_ID = "mfe-content-root";

let singleSpaConfigured = false;
let singleSpaStarted = false;

function hasMfeHost() {
    return Boolean(document.getElementById(MFE_HOST_ID));
}

function guardedActiveWhen(
    appName: string,
    routeActiveWhen: (location: Location) => boolean
) {
    return (location: Location) => {
        const routeActive = routeActiveWhen(location);

        if (!routeActive) {
            return false;
        }

        const hostReady = hasMfeHost();

        if (!hostReady) {
            console.warn(
                `[SHELL] ${appName} active route matched, but #${MFE_HOST_ID} is not mounted yet. Mount skipped.`
            );
            return false;
        }

        return true;
    };
}

function registerMicrofrontendsOnce() {
    if (singleSpaConfigured) return;

    console.log("[SHELL] configuring single-spa root-config", window.location.pathname);

    addErrorHandler((err) => {
        console.error("[SHELL][single-spa error]", err);
    });

    registerApplication({
        name: MICROFRONTENDS.legacy.name,
        app: () => {
            console.log("[SHELL] loading legacy app...");
            return import(MICROFRONTENDS.legacy.name).then((mod) => {
                console.log("[SHELL] legacy module loaded:", Object.keys(mod));
                return mod;
            });
        },
        activeWhen: guardedActiveWhen(
            MICROFRONTENDS.legacy.name,
            MICROFRONTENDS.legacy.activeWhen
        ),
    });

    registerApplication({
        name: MICROFRONTENDS.access.name,
        app: () => {
            console.log("[SHELL] loading access-builder app...");
            return import(MICROFRONTENDS.access.name).then((mod) => {
                console.log("[SHELL] access-builder module loaded:", Object.keys(mod));
                return mod;
            });
        },
        activeWhen: guardedActiveWhen(
            MICROFRONTENDS.access.name,
            MICROFRONTENDS.access.activeWhen
        ),
    });

    singleSpaConfigured = true;
}

export function ensureSingleSpaRuntimeStarted() {
    registerMicrofrontendsOnce();

    if (!hasMfeHost()) {
        console.warn(
            `[SHELL] single-spa start skipped: #${MFE_HOST_ID} not mounted yet`
        );
        return false;
    }

    if (!singleSpaStarted) {
        console.log("[SHELL] starting single-spa runtime");
        start();
        singleSpaStarted = true;
        return true;
    }

    triggerAppChange();
    return true;
}