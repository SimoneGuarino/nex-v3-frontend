import { useEffect } from "react";
import { ensureSingleSpaRuntimeStarted } from "../root-config";

export default function SingleSpaRuntime() {
    useEffect(() => {
        ensureSingleSpaRuntimeStarted();
    }, []);

    return null;
}