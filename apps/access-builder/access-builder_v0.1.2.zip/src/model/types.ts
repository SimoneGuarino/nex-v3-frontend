export type ObjectIdString = string;
export type TenantKey = "Focelda" | "IOT" | string;

export type GroupStatus = "ACTIVE" | "DISABLED";
export type GroupKind = "ORG_UNIT" | "TEAM" | "ROLE_GROUP" | "CAPABILITY_GROUP";
export type PrincipalType = "GROUP" | "USER";
export type GrantEffect = "ALLOW" | "DENY";
export type ResourceType = "PANEL" | "ACTION" | "DATA_SCOPE";
export type ScopeKind = "GLOBAL" | "ORG_UNIT" | "BUYER_CODE" | "AGENT_CODE" | "FAMIGLIA" | "LINEA" | "GRUPPO" | "QUOTATION_ID" | "LOOK_ID";

export interface RoleOption {
  id: number;
  name: string;
  description?: string;
}

export interface UserSummary {
  _id: ObjectIdString;
  nome?: string;
  cognome?: string;
  username: string;
  ruolo?: string | string[];
  desc_role?: string | string[];
  disabilitato?: boolean;
}

export interface AccessGroup {
  _id: ObjectIdString;
  tenant: TenantKey;
  key: string;
  name: string;
  description?: string;
  status: GroupStatus;
  kind: GroupKind;
  managerUserId?: ObjectIdString | null;
  parentGroupIds?: ObjectIdString[];
  membersCount?: number;
  grantsCount?: number;
  inheritedGrantsCount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface GroupEdge {
  _id: ObjectIdString;
  tenant: TenantKey;
  parentGroupId: ObjectIdString;
  childType: "GROUP";
  childGroupId: ObjectIdString;
}

export interface GroupMembership {
  _id: ObjectIdString;
  tenant: TenantKey;
  groupId: ObjectIdString;
  userId: ObjectIdString;
  expiresAt?: string | null;
  note?: string;
  user?: UserSummary;
}

export interface PermissionScope {
  kind: ScopeKind;
  value?: string | null;
}

export interface PermissionGrant {
  _id: ObjectIdString;
  tenant: TenantKey;
  principalType: PrincipalType;
  principalId: ObjectIdString;
  permission: string;
  effect: GrantEffect;
  scope: PermissionScope;
  context?: {
    actorRoles?: number[];
  };
  createdBy?: ObjectIdString | null;
  expiresAt?: string | null;
  source?: "DIRECT" | "INHERITED" | "USER_OVERRIDE";
  sourceGroupId?: ObjectIdString;
}

export interface NavigationResource {
  _id: ObjectIdString;
  tenant: TenantKey;
  appId: "legacy" | "shell" | string;
  key: string;
  type: ResourceType;
  name: string;
  route?: string;
  parentKey?: string | null;
  permission: string;
  order?: number;
  status: "ACTIVE" | "DISABLED";
  meta?: Record<string, unknown>;
}

export interface EffectiveAccessPreview {
  tenant: TenantKey;
  userId: ObjectIdString;
  actorRole: number;
  version: string;
  groups: Array<AccessGroup & { inherited?: boolean }>;
  caps: string[];
  panels: NavigationResource[];
  grants: PermissionGrant[];
  denied: Array<{ permission: string; source: "GROUP" | "USER"; sourceId: ObjectIdString }>;
}

export interface AccessBuilderSnapshot {
  tenant: TenantKey;
  roles: RoleOption[];
  groups: AccessGroup[];
  edges: GroupEdge[];
  memberships: GroupMembership[];
  grants: PermissionGrant[];
  resources: NavigationResource[];
  users: UserSummary[];
  effectivePreview?: EffectiveAccessPreview;
}

export interface PendingChange {
  id: string;
  type: "GROUP_CREATE" | "GROUP_UPDATE" | "EDGE_CREATE" | "EDGE_DELETE" | "MEMBERSHIP_ADD" | "MEMBERSHIP_REMOVE" | "GRANT_ADD" | "GRANT_REMOVE";
  label: string;
  payload: unknown;
  createdAt: string;
}
