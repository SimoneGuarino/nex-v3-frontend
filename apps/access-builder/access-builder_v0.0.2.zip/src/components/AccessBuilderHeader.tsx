import { notifyShellLoadingReady, toggleGlobalPanel } from "@nex/shared-platform";
import type { PendingChange } from "../model/types";

interface Props {
  pendingChanges: PendingChange[];
  onPublish: () => Promise<{ ok: true; applied: number }>;
}

export function AccessBuilderHeader({ pendingChanges, onPublish }: Props) {
  return (
    <header className="ab-header">
      <div>
        <div className="ab-eyebrow">NEX v3 · Access Control</div>
        <h1>Access Builder</h1>
      </div>

      <div className="ab-header-actions">
        <button type="button" className="ab-button ab-button-ghost" onClick={() => toggleGlobalPanel("notifications", { source: "access-builder" })}>
          Notifiche
        </button>
        <button type="button" className="ab-button ab-button-ghost" onClick={() => toggleGlobalPanel("chat", { source: "access-builder" })}>
          Chat
        </button>
        <button type="button" className="ab-button ab-button-ghost" onClick={() => notifyShellLoadingReady({ app: "access-builder", source: "manual-ready" })}>
          Ready
        </button>
        <button type="button" className="ab-button ab-button-primary" disabled={pendingChanges.length === 0} onClick={onPublish}>
          Pubblica {pendingChanges.length > 0 ? `(${pendingChanges.length})` : ""}
        </button>
      </div>
    </header>
  );
}
