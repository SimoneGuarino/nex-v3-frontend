import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import AccessAppBootstrap from "./AccessAppBootstrap";
import "./styles.css";

const basename = import.meta.env.BASE_URL.replace(/\/$/, "") || "/";

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
    <React.StrictMode>
        <BrowserRouter basename={basename}>
            <AccessAppBootstrap>
                <App />
            </AccessAppBootstrap>
        </BrowserRouter>
    </React.StrictMode>,
);
